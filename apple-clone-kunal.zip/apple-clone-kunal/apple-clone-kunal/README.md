Apple Website Readme
This repository contains the HTML, CSS, and JavaScript code for a simple Apple product showcase website. The website includes sections for iMac, iPhone 12 Pro, iPhone 12, and Apple Watch. Below is an overview of the structure and features of the website.

Table of Contents
Folder Structure
HTML Structure
CSS Styles
JavaScript Functionality
Folder Structure
css: This folder contains the stylesheet file styles.css used to style the HTML elements.

images: This folder may include images used in the website. Ensure all image paths in the HTML are correct.

js: The main.js file in this folder contains JavaScript functions used for any interactive elements on the website.

HTML Structure
The HTML file, index.html, is structured as follows:

Head Section: Contains meta information, title, and links to the external stylesheet and JavaScript files.

Body Section: Divided into a header, sections for iMac, iPhone 12 Pro, iPhone 12, Apple Watch, and a footer.

Header: Contains a navigation bar with links to different sections and icons for mobile responsiveness.

Sections: Each section corresponds to a product (iMac, iPhone 12 Pro, iPhone 12, Apple Watch) and includes a title, subheading, price, and call-to-action buttons.

Footer: Displays a simple copyright notice.

CSS Styles
The styling is defined in the styles.css file and is linked to the HTML file. The CSS provides a responsive and visually appealing layout for the website.

JavaScript Functionality
The main.js file includes scripts for potential interactive elements on the website. Currently, it is linked but appears to be empty. 